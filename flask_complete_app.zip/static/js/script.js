function showMessage() {
    alert("All files loaded successfully!");
}
